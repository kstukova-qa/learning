# 01_02 What is CI CD

## References and Documentation

- [About continuous integration](https://docs.github.com/en/actions/automating-builds-and-tests/about-continuous-integration)
